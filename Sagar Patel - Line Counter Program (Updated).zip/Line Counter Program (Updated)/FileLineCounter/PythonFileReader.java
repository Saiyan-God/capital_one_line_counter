import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
/**
 * The parser for Python files
 */
public class PythonFileReader implements CodeFileReader
{
    /**
     * This method will parse the Python file given and place all metrics in the returning CodeFileInfo object
     * 
     * @param   filePath    file to parse
     * @param   outputFile  file to place output to (future work)
     * @return              the CodeFileInfo object with all the metric information found
     */
    public CodeFileInfo generateReport(String filePath, String outputFile)
    {
        BufferedReader reader;
        
        //initialize all the metrics
        int numLines = 0;
        int numCommentLines = 0;
        int numSingleLineComments = 0;
        int numBlockComments = 0;
        int numBlockLineComments = 0;
        int numToDos = 0;
        
        //check if the previous line is part of a code block
        boolean prevLineBlockComment = false;
        //check if the current block has already been accounted for
        boolean addedBlock = false;
        try{
            //read the file line by line
            reader = new BufferedReader(new FileReader(filePath));
            String line = reader.readLine();
            while(line != null){
                //convert to lowercase so that TODO, todo, ToDo, etc all are checked for with "todo", and trim leading spaces to check for comment blocks
                line = line.toLowerCase().trim();
                numLines++;
            
                if(line.contains("todo")){
                    numToDos++;
                }
                
                //check if the current comment is part of a block or just a single line comment
                if(line.length() > 0 && line.charAt(0)=='#'){
                    numCommentLines++;
                    if(prevLineBlockComment){
                        if(!addedBlock){
                            addedBlock = true;
                            numSingleLineComments--;
                            numBlockLineComments++;
                            numBlockComments+=2;
                        }
                        else{
                            numBlockComments++;
                        }
                    }
                    else {
                        prevLineBlockComment = true;
                        numSingleLineComments++;
                    }
                }
                else if(line.indexOf("#") != -1){
                    prevLineBlockComment = false;
                    addedBlock = false;
                    numCommentLines++;
                    numSingleLineComments++;
                }
                else{
                    prevLineBlockComment = false;
                    addedBlock = false;
                }
                
                line = reader.readLine();
            }
            reader.close();
        }
        catch (IOException e) {
            System.out.println("Error occured");
            e.printStackTrace();
        }
                
        return new CodeFileInfo(numLines, numCommentLines, numSingleLineComments,
                                numBlockComments, numBlockLineComments, numToDos);
    }
}
