import java.io.*;
/**
 * The class with the main function. This class starts the project by initializing the appropriate objects
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FileLineCounter
{
    public static void main(String[] args){
        //get the file to check
        FileSelector fs = new FileSelector();
        fs.selectFile();
        
        //check if the file is valid
        File f = new File(fs.getFileName());
        if(f.exists()){
            FileReaderFactory factory = new FileReaderFactory();
            CodeFileReader fr = factory.getFileReader(fs.getFileName());
            
            // check if there is an available parser
            if(fr != null){
                //acquire metrics about comments and number of lines
                CodeFileInfo cfi= fr.generateReport(fs.getFileName(), "");
                cfi.print();
            }
            else{
                System.out.println("File not supported");
            }
        }
        else{
            System.out.println("File not found");
        }
    }
}
