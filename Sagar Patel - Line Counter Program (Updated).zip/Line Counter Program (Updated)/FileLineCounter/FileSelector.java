/**
 * This file selects the file to parse. This is meant to be a GUI for users to select a file to parse
 */
public class FileSelector
{
    private String fileName;
    /**
     * Set the current file name to null
     */
    public FileSelector()
    {
        this.fileName = null;
    }

    /**
     * This function would allow users to select a file throuhgh a GUI (in progress)
     * 
     * @return     if a file has been chosen
     */
    public boolean selectFile()
    {
        // enter the name of the file to check here
        this.fileName = "";
        //ex: this.fileName = "C:/Users/User1/Documents//Test Files/test_1.java";
        return true;
    }
    
    /**
     * Returns the name of the file selected
     */
    public String getFileName(){
        return this.fileName;
    }
}
