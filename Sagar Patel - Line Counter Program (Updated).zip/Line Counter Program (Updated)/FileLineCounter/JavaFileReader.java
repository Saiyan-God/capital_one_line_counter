import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
/**
 * The parser for Java and JavaScript files
 */
public class JavaFileReader implements CodeFileReader
{
    /**
     * This method will parse the Java or JavsScript given and place all metrics in the returning CodeFileInfo object
     * 
     * @param   filePath    file to parse
     * @param   outputFile  file to place output to (future work)
     * @return              the CodeFileInfo object with all the metric information found
     */
    public CodeFileInfo generateReport(String filePath, String outputFile)
    {
        BufferedReader reader;
        
        //initialize all the metrics
        int numLines = 0;
        int numCommentLines = 0;
        int numSingleLineComments = 0;
        int numBlockComments = 0;
        int numBlockLineComments = 0;
        int numToDos = 0;
        
        try{
            //read the file line by line
            
            reader = new BufferedReader(new FileReader(filePath));
            String line = reader.readLine();
            while(line != null){
                //convert to lowercase so that TODO, todo, ToDo, etc all are checked for with "todo"
                line = line.toLowerCase();
                numLines++;

                // used to get index where block comment ends in case there is a single line comment on the same line
                int lastIndex = 0;
                
                //used in case there are multiple block comments or single line comments on the same line
                String startingLine = "";
                
                //check if the line has a comment block within it. If it exists, continue iterating through the lines until the block is closed
                while(line.indexOf("/*", lastIndex) != -1){
                    numBlockComments++;
                    numCommentLines++;
                    startingLine = line;
                    lastIndex = line.indexOf("/*", lastIndex) + 1;
                    while(line != null){
                        line = line.toLowerCase();
                        if(!line.equals(startingLine)){
                            numBlockComments++;
                            numCommentLines++;
                        }
                        int endOfCommentBlock = line.indexOf("*/", lastIndex);
                        if(endOfCommentBlock != -1){
                            numBlockLineComments++;
                            lastIndex = endOfCommentBlock + 1;
                            startingLine = line;
                            break;
                        }
                        lastIndex = 0;
                        numLines++;
                        if(line.contains("todo")){
                            numToDos++;
                        }
                        line = reader.readLine();
                    }
                }
                
                if(line.indexOf("//", lastIndex) != -1){
                    //if lastIndex isnt 0, it means that there could have been block comments on the same line and we should not increment the total number of commented lines
                    if(lastIndex != 0){
                        numCommentLines++;
                    }
                    numSingleLineComments++;
                }
                
                if(line.indexOf("todo", lastIndex) != -1){
                    numToDos++;
                }
                
                line = reader.readLine();
            }
            reader.close();
        }
        catch (IOException e) {
            System.out.println("Error occured");
            e.printStackTrace();
        }
                
        return new CodeFileInfo(numLines, numCommentLines, numSingleLineComments,
                                numBlockComments, numBlockLineComments, numToDos);
    }
}
