
/**
 * This interface allows for programming file parsers to be used depending on what file is presented
 */
public interface CodeFileReader
{
    /**
     * This method will parse the file given and place all metrics in the returning CodeFileInfo object
     * 
     * @param   filePath    file to parse
     * @param   outputFile  file to place output to
     * @return              the CodeFileInfo object with all the metric information found
     */
    CodeFileInfo generateReport(String filePath, String outputFile);
}
