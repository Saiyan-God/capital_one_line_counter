import java.util.*;
/**
 * This file returns the appropriate programming file parser suitable for the file type presented, following
 * the Factory Design pattern
 */
public class FileReaderFactory
{
    // map that holds all types of parsers
    private Map<String, CodeFileReader> fileReaderDir;

    /**
     * Initialize the factory map
     */
    public FileReaderFactory()
    {
        fileReaderDir = new HashMap();
        
        fileReaderDir.put("java", new JavaFileReader());
        fileReaderDir.put("js", new JavaFileReader());
        fileReaderDir.put("py", new PythonFileReader());
    }

    /**
     * Select the appropriate programming file parser from the map.
     * If the file type does not exist, it will return null
     * 
     * @param  filePath     the path to the file
     * @return              a suitable file parser    
     */
    public CodeFileReader getFileReader(String filePath)
    {
        return fileReaderDir.get(getExtFromFileName(filePath));
    }
    
    /**
     * Gets the file extension from the file path. Also check if it starts with a '.'
     * 
     * @param  filePath     the path to the file
     * @return              the file extension    
     */    
    public static String getExtFromFileName(String filePath){
        String fileName = filePath.substring(filePath.lastIndexOf("/")+1);
        if(fileName.charAt(0)=='.'){
            return "";
        }
        String[] arr = fileName.split("\\.");
        return arr.length > 0 ? arr[arr.length-1] : "";
    }
}
