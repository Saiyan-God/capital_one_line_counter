
/**
 * This class represents the object that holds all of the matrics regarding a programming file
 */
public class CodeFileInfo
{
    private int numLines;
    private int numCommentLines;
    private int numSingleLineComments;
    private int numBlockComments;
    private int numBlockLineComments;
    private int numToDos;

    /**
     * Initialize all the fields with the values found from the programming file
     */
    public CodeFileInfo(int numLines, int numCommentLines, int numSingleLineComments,
                            int numBlockComments, int numBlockLineComments, int numToDos)
    {
        this.numLines = numLines;
        this.numCommentLines = numCommentLines;
        this.numSingleLineComments = numSingleLineComments;
        this.numBlockComments = numBlockComments;
        this.numBlockLineComments = numBlockLineComments;
        this.numToDos = numToDos;
    }
    
    /**
     * Return a string representation of the metrics
     */
    public String toString(){
        return "Total # of lines: " + this.getNumLines() + "\n" +
                "Total # of comment lines: " + this.getNumCommentLines() + "\n" +
                "Total # of single line comments: " + this.getNumSingleLineComment() + "\n" + 
                "Total # of comment lines within block comments: " + this.getNumBlockComments() + "\n" +
                "Total # of block line comments: " + this.getNumBlockLineComments() + "\n" +
                "Total # of TODO's: " + this.getNumToDos() + "\n";
    }
    
    /**
     * Print out the metrics found
     */
    public void print(){
        System.out.println(this.toString());
    }

    public int getNumLines()
    {
        return this.numLines;
    }
    
    public int getNumCommentLines()
    {
        return this.numCommentLines;
    }
    
    public int getNumSingleLineComment()
    {
        return this.numSingleLineComments;
    }
    
    public int getNumBlockComments()
    {
        return this.numBlockComments;
    }
    
    public int getNumBlockLineComments()
    {
        return this.numBlockLineComments;
    }
    
    public int getNumToDos()
    {
        return this.numToDos;
    }
}
